function s = head_score(h, F)
Z = (F - h.mu) ./ h.sd;
s = Z*h.w(1:end-1) + h.w(end);
end
