function cfg = config_FCFWSO(fast)
% CONFIG_FCFWSO  All parameters of the FCFWSO_GRA-Net pipeline (paper Table 1 + extras).
%   cfg = config_FCFWSO()      -> full settings
%   cfg = config_FCFWSO(true)  -> quick settings for testing
if nargin < 1, fast = false; end
cfg.seed = 1;  cfg.plotVisible = 'on';  cfg.resultsDir = 'results';

% ---------------- MANET parameters (Table 1) ----------------
cfg.numNodes = 100;  cfg.area = [1000 1000];  cfg.range = 250;       % m
cfg.E0 = 100;        cfg.Etx = 0.5;  cfg.Erx = 0.25;                 % J (per packet)
cfg.simTime = 100;   cfg.pktRate = 1;  cfg.pktBits = 4096;           % s, pkt/s, bits
cfg.bandwidthKbps = 200;  cfg.maxDelayMs = 50;
cfg.maxSpeed = 10;   cfg.malFrac = 0.2;  cfg.dropMal = 0.8;  cfg.dropHon = 0.02;
cfg.numFlows = 5;    cfg.routeInterval = 10;   cfg.trustThr = 0.5;
cfg.fitW = ones(1,8)/8;     % weights of Eq.(7): [energy dist delay trust power conn lifetime mobility]

% ---------------- FCWSO optimiser parameters (Table 1) ----------------
cfg.opt.stopFit = 1e-3;   cfg.opt.envFactor = 0.5;  cfg.opt.sharkSpeed = 1.0;
cfg.opt.huntProb = 0.7;   cfg.opt.huntRadius = 0.5; cfg.opt.convRate = 0.9;   % convRate = fractional order alpha
cfg.opt.reproProb = 0.5;  cfg.opt.pop = 20;         cfg.opt.iter = 30;       % routing optimiser size

% ---------------- GRA-Net ----------------
cfg.net.L = 8;  cfg.net.blocks = 2;  cfg.net.ks = 7;  cfg.net.expand = 2;
cfg.net.groups = 4;  cfg.net.pool = 8;  cfg.net.ridge = 1e-2;
cfg.net.pop = 12;  cfg.net.iter = 15;  cfg.net.optRows = 1200;          % FCWSO training of GRA-Net

% ---------------- Datasets ----------------
cfg.data.nsl     = {'data/KDDTrain+.txt','data/KDDTest+.txt'};     % NSL-KDD
cfg.data.cic     = {'data/ids2018.csv'};                           % CSE-CIC-IDS2018 csv file(s)
cfg.data.maxRows = 12000;   cfg.data.readRows = 200000;

% ---------------- Detection / analyses ----------------
cfg.det.methods = {'FCWSO','WSO','COA','none'};   % -> FCFWSO_GRA-Net, WSO_GRA-Net, COA_GRA-Net, GRA-Net
cfg.kDefault = 5;  cfg.kList = [6 7 8 9 10];
cfg.routeMethods = {'FCWSO','COA','WSO','SHORTEST'};
cfg.nodeList = 100:100:500;

if fast
    cfg.opt.pop = 10; cfg.opt.iter = 8; cfg.numFlows = 3; cfg.simTime = 40;
    cfg.net.pop = 8; cfg.net.iter = 5; cfg.net.optRows = 600; cfg.data.maxRows = 3000;
    cfg.kList = [3 4]; cfg.kDefault = 3; cfg.nodeList = [50 100]; cfg.plotVisible = 'off';
end
end
