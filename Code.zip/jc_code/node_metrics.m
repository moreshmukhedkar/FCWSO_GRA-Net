function m = node_metrics(net, cfg)
% NODE_METRICS  Topology + fitness ingredients of Eq.(1)-(4), (9)-(12).
N = net.N;
dx = net.pos(:,1) - net.pos(:,1)';   dy = net.pos(:,2) - net.pos(:,2)';
D = sqrt(dx.^2 + dy.^2);
alive = net.energy > 0;
A = (D <= cfg.range) & ~eye(N) & (alive & alive');
m.D = D;  m.A = A;  m.deg = sum(A,2);
m.Enorm = net.energy / cfg.E0;                                   % Eq.(1): remaining energy (normalised)
m.conn  = m.deg / max(max(m.deg),1);                             % Eq.(11): connectivity
dxp = net.prevPos(:,1) - net.prevPos(:,1)';   dyp = net.prevPos(:,2) - net.prevPos(:,2)';
Dp = sqrt(dxp.^2 + dyp.^2);
rel = abs(D - Dp) .* A;                                          % Eq.(2)-(4): relative mobility over hello intervals
m.mob = min((sum(rel,2) ./ max(m.deg,1)) / (2*cfg.maxSpeed*net.dt), 1);
m.Pl  = max(0, 1 - log10(max(D,1))/log10(cfg.range));            % Eq.(10): link received power (dB-normalised to [0,1])
rate = (net.spent + cfg.Etx) / (net.time + 1);                   % J/s energy dissipation
life = net.energy ./ max(rate,1e-3);   m.life = life / max(max(life),eps);   % Eq.(12): lifetime
m.T = net.trust;
end
