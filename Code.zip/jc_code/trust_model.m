function feat = trust_model(net, cfg, m)
% TRUST_MODEL  Direct trust (Eq.5), indirect trust (Eq.6) and the GRA-Net trust-feature vector (N x 7).
N = net.N;  A = m.A;
texp = 10;                                                  % expected public-key verification time (ms)
tact = texp*(1 + 0.15*abs(randn(N,N)));                     % actual verification time
mal = find(net.isMal);
tact(:,mal) = tact(:,mal) .* (1.5 + 1.5*rand(N,numel(mal)));
fwd = net.fwdOK ./ net.fwdTot;                              % watchdog forwarding ratio
DTij = A .* (0.5*min(1,texp./tact) + 0.5*min(1,max(0, fwd' + 0.05*randn(N,N))));
deg = max(m.deg,1);
DT  = sum(DTij,1)' ./ deg;                                  % direct trust of each node (mean over observers)
w   = A .* net.trust;                                       % recommendations weighted by recommender trust
IT  = sum(w .* DTij,1)' ./ max(sum(w,1)',1e-6);             % indirect trust
iso = m.deg==0;  DT(iso) = 0.5;  IT(iso) = 0.5;
late = sum(A .* (tact/texp),1)' ./ deg;                     % mean verification lateness
feat = [DT IT fwd m.Enorm m.mob m.conn late];
end
