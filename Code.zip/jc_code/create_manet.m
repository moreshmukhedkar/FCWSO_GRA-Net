function net = create_manet(cfg, N)
% CREATE_MANET  Random MANET: positions, waypoints, energy, malicious nodes, watchdog counters.
net.N = N;
net.pos = rand(N,2) .* cfg.area;   net.prevPos = net.pos;   net.wp = rand(N,2) .* cfg.area;
net.speed = zeros(N,1);
net.energy = cfg.E0 * ones(N,1);   net.spent = zeros(N,1);
net.isMal = false(N,1);  net.isMal(randperm(N, round(cfg.malFrac*N))) = true;
net.trust = 0.5*ones(N,1);
net.fwdOK = ones(N,1);   net.fwdTot = 2*ones(N,1);      % watchdog counters (prior 1/2)
net.dt = cfg.routeInterval;   net.time = 0;
end
