function h = fit_head(F, y, lambda)
% FIT_HEAD  Ridge-regression output layer on standardised GRA-Net features (closed form).
h.mu = mean(F,1);  h.sd = std(F,0,1) + 1e-8;
Z = [(F - h.mu) ./ h.sd, ones(size(F,1),1)];
R = lambda * size(Z,1) * eye(size(Z,2));  R(end,end) = 0;
h.w = (Z'*Z + R) \ (Z'*y(:));
end
