function fold = stratified_folds(y, k)
% Stratified k-fold assignment (fold id 1..k per row).
y = y(:);  fold = zeros(numel(y),1);
for c = unique(y)'
    ic = find(y == c);  ic = ic(randperm(numel(ic)));
    fold(ic) = mod(0:numel(ic)-1, k)' + 1;
end
end
