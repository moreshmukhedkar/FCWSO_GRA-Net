function R = analysis_routing(cfg, tnet)
% ANALYSIS_ROUTING  Routing analysis vs simulation time: PDR, throughput, lifetime, delay, energy, distance.
M = cfg.routeMethods;  N = cfg.numNodes;
names = {'PDR','Throughput (kbps)','Network lifetime (s)','End-to-end delay (ms)','Residual energy (J)','Route distance (m)'};
flds  = {'pdr','throughput','lifetime','delay_ms','energy','distance'};
R = struct();
for i = 1:numel(M)
    fprintf('  routing analysis: %s\n', method_label(M{i}));
    R.(M{i}) = simulate_manet(cfg, N, M{i}, cfg.seed, tnet);
end
figure('Visible', cfg.plotVisible, 'Position',[50 50 1250 650]);
for k = 1:numel(flds)
    subplot(2,3,k);  hold on;
    for i = 1:numel(M), plot(R.(M{i}).t, R.(M{i}).(flds{k}), '-o', 'LineWidth',1.4); end
    xlabel('Simulation time (s)');  ylabel(names{k});  grid on;  box on;
    if k == 1, legend(cellfun(@method_label, M, 'UniformOutput',false), 'Location','best'); end
end
sgtitle(sprintf('Routing analysis (%d nodes)', N));
saveas(gcf, fullfile(cfg.resultsDir, 'fig_routing_analysis.png'));
H = {'time'};  Mx = R.(M{1}).t(:);
for i = 1:numel(M), for k = 1:numel(flds)
    H{end+1} = [M{i} '_' flds{k}];  Mx = [Mx R.(M{i}).(flds{k})(:)]; end, end %#ok<AGROW>
save_csv(fullfile(cfg.resultsDir,'routing_analysis.csv'), H, Mx);
end
