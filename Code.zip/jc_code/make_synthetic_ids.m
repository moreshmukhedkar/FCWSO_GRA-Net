function [raw, y] = make_synthetic_ids(name, n)
% MAKE_SYNTHETIC_IDS  Stand-in data (used ONLY when the real CSV files are missing) so the code runs.
nf = 38;  pa = 0.47;
if ~strcmpi(name,'nsl-kdd'), nf = 76;  pa = 0.25; end
y = rand(n,1) < pa;
shift = zeros(1,nf);  ni = round(nf/2);  shift(1:ni) = 0.5 + 0.8*rand(1,ni);
X = randn(n,nf) + double(y)*shift;
X(:,1:2:end) = exp(0.8*X(:,1:2:end));
X(rand(n,nf) < 0.02) = NaN;
if ~strcmpi(name,'nsl-kdd'), X(rand(n,nf) < 0.005) = Inf; end
raw.cols = cell(1,nf);  for j = 1:nf, raw.cols{j} = X(:,j); end
if strcmpi(name,'nsl-kdd')
    pr = {'tcp','udp','icmp'};  ip = randi(3,n,1);  ip(y & rand(n,1) < 0.4) = 3;
    sv = arrayfun(@(k) sprintf('svc%d',k), randi(20,n,1), 'UniformOutput', false);
    fl = arrayfun(@(k) sprintf('flag%d',k), randi(11,n,1), 'UniformOutput', false);
    raw.cols{end+1} = pr(ip)';  raw.cols{end+1} = sv;  raw.cols{end+1} = fl;
end
end
