function [Z, lo, hi] = minmax_scale(X, lo, hi)
% MINMAX_SCALE  Feature normalisation to [0,1] (statistics from training data when lo/hi are given).
if nargin < 3, lo = min(X,[],1);  hi = max(X,[],1); end
rg = hi - lo;  rg(rg == 0) = 1;
Z = min(max((X - lo) ./ rg, 0), 1);
end
