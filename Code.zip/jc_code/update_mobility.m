function net = update_mobility(net, cfg, dt)
% UPDATE_MOBILITY  Random-waypoint movement for dt seconds.
net.prevPos = net.pos;   net.dt = dt;
d = net.wp - net.pos;   dist = sqrt(sum(d.^2,2));
spd = max(1, cfg.maxSpeed*rand(net.N,1));   step = spd*dt;
arrive = dist <= step;
net.pos = net.pos + (d ./ max(dist,eps)) .* min(step, dist);
net.wp(arrive,:) = rand(nnz(arrive),2) .* cfg.area;
net.pos = min(max(net.pos,0), cfg.area);
net.speed = sqrt(sum((net.pos-net.prevPos).^2,2)) / dt;
end
