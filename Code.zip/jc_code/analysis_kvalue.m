function R = analysis_kvalue(cfg, datasets)
% ANALYSIS_KVALUE  Detection performance for varying k (k-fold value) on each dataset.
if nargin < 2, datasets = {'NSL-KDD','CIC-IDS2018'}; end
M = cfg.det.methods;  K = cfg.kList;
names = {'Accuracy','Precision','Recall','Miss rate','False alarm'};   % columns 1..5 of metric vector
R = struct();
for d = 1:numel(datasets)
    [X,y] = load_dataset(datasets{d}, cfg);
    res = zeros(numel(K), numel(M), 5);
    for a = 1:numel(K)
        for i = 1:numel(M)
            fprintf('  k-analysis: %s, k=%d, %s\n', datasets{d}, K(a), method_label(M{i}));
            mv = evaluate_kfold(X, y, cfg, M{i}, K(a));
            res(a,i,:) = mv(1:5);
        end
    end
    R.(matlab.lang.makeValidName(datasets{d})) = res;
    figure('Visible', cfg.plotVisible, 'Position',[50 50 1250 650]);
    for k = 1:5
        subplot(2,3,k);  plot(K, squeeze(res(:,:,k)), '-o', 'LineWidth',1.4);
        xlabel('k value');  ylabel(names{k});  grid on;  box on;
        if k == 1, legend(cellfun(@method_label, M, 'UniformOutput',false), 'Location','best'); end
    end
    sgtitle(['Detection analysis vs k - ' datasets{d}]);
    tag = lower(regexprep(datasets{d},'[^a-zA-Z0-9]',''));
    saveas(gcf, fullfile(cfg.resultsDir, ['fig_kvalue_' tag '.png']));
    H = {'k'};  Mx = K(:);
    for i = 1:numel(M), for k = 1:5, H{end+1} = [M{i} '_' strrep(names{k},' ','')];  Mx = [Mx res(:,i,k)]; end, end %#ok<AGROW>
    save_csv(fullfile(cfg.resultsDir, ['kvalue_' tag '.csv']), H, Mx);
end
end
