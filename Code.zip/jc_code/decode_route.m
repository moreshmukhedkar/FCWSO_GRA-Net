function path = decode_route(key, A, src, dst)
% DECODE_ROUTE  Solution encoding (Sec.4.1): one priority key per node. The route is built by
%   key-guided depth-first search (highest-key unvisited neighbour first, with back-tracking).
N = numel(key);  visited = false(1,N);  stack = zeros(1,N);  sp = 1;  stack(1) = src;  visited(src) = true;
while sp > 0
    cur = stack(sp);
    if cur == dst, path = stack(1:sp); return; end
    if A(cur,dst) && ~visited(dst)
        nxt = dst;
    else
        nb = find(A(cur,:) & ~visited);
        if isempty(nb), sp = sp - 1; continue; end
        [~,k] = max(key(nb));  nxt = nb(k);
    end
    visited(nxt) = true;  sp = sp + 1;  stack(sp) = nxt;
end
path = [];
end
