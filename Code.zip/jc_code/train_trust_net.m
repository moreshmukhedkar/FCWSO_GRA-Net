function tnet = train_trust_net(cfg)
% TRAIN_TRUST_NET  Trains the GRA-Net used for trust updation on behaviour simulated from random MANETs.
X = [];  y = [];
for r = 1:8
    n = 60;  net = create_manet(cfg, n);
    net.fwdTot = randi([2 40], n, 1);
    p = cfg.dropHon*ones(n,1);  p(net.isMal) = cfg.dropMal;
    net.fwdOK = arrayfun(@(a,b) sum(rand(a,1) > b), net.fwdTot, p);
    net.energy = cfg.E0*(0.3 + 0.7*rand(n,1));
    net = update_mobility(net, cfg, cfg.routeInterval);
    m = node_metrics(net, cfg);
    X = [X; trust_model(net, cfg, m)];  y = [y; double(~net.isMal)]; %#ok<AGROW>
end
tnet = train_granet(X, y, cfg, 'none');
end
