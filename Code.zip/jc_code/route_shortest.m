function path = route_shortest(A, src, dst)
% ROUTE_SHORTEST  Min-hop (AODV-like, trust-unaware) baseline route.
N = size(A,1);  par = zeros(1,N);  seen = false(1,N);  seen(src) = true;
q = zeros(1,N);  qh = 1;  qt = 1;  q(1) = src;
while qh <= qt && ~seen(dst)
    u = q(qh);  qh = qh + 1;
    nb = find(A(u,:) & ~seen);
    par(nb) = u;  seen(nb) = true;  q(qt+1:qt+numel(nb)) = nb;  qt = qt + numel(nb);
end
if ~seen(dst), path = []; return; end
path = dst;  while path(1) ~= src, path = [par(path(1)) path]; end
end
