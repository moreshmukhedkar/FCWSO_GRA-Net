function [X, y, info] = load_dataset(name, cfg)
% LOAD_DATASET  Reads NSL-KDD or CSE-CIC-IDS2018, binarises labels (1 = attack), preprocesses.
%   If the files listed in cfg.data are not found, synthetic stand-in data is generated (with a warning).
info.synthetic = false;
switch lower(name)
    case 'nsl-kdd'
        files = cfg.data.nsl(cellfun(@(f) exist(f,'file')==2, cfg.data.nsl));
        if isempty(files)
            [raw,y] = make_synthetic_ids(name, cfg.data.maxRows);  info.synthetic = true;
        else
            parts = cell(1,numel(files));
            for i = 1:numel(files)
                T = readtable(files{i}, 'FileType','text', 'Delimiter',',', 'ReadVariableNames',false);
                if ~isnumeric(T.(1)), T(1,:) = []; end          % file had a header row
                parts{i} = T;
            end
            T = vertcat(parts{:});
            lab = T.(42);
            if isnumeric(lab), y = lab ~= 0; else, y = ~strcmpi(strtrim(cellstr(lab)),'normal'); end
            raw = raw_from_table(T(:,1:41));
        end
    case 'cic-ids2018'
        files = cfg.data.cic(cellfun(@(f) exist(f,'file')==2, cfg.data.cic));
        if isempty(files)
            [raw,y] = make_synthetic_ids(name, cfg.data.maxRows);  info.synthetic = true;
        else
            parts = cell(1,numel(files));
            for i = 1:numel(files)
                ds = tabularTextDatastore(files{i}, 'TreatAsMissing',{'NaN','Infinity','inf'}, 'ReadSize',cfg.data.readRows);
                parts{i} = read(ds);
            end
            T = vertcat(parts{:});
            vn = T.Properties.VariableNames;
            li = find(strcmpi(vn,'Label'), 1);
            lab = strtrim(cellstr(T.(li)));
            keep = ~strcmpi(lab,'Label');  T = T(keep,:);  lab = lab(keep);   % repeated header rows
            y = ~strcmpi(lab,'benign');
            drop = ismember(lower(regexprep(vn,'[^a-zA-Z]','')), {'label','timestamp','flowid','srcip','dstip','sourceip','destinationip'});
            raw = raw_from_table(T(:,~drop));
        end
    otherwise
        error('Unknown dataset %s', name);
end
if info.synthetic
    warning('load_dataset:synthetic', 'Dataset files for %s not found - using SYNTHETIC stand-in data. Put the real files in cfg.data paths.', name);
end
y = double(y(:));
[X, pinfo] = preprocess_data(raw);
if size(X,1) > cfg.data.maxRows
    idx = stratified_sample(y, cfg.data.maxRows);  X = X(idx,:);  y = y(idx);
end
info.numFeatures = pinfo.numFeatures;  info.n = numel(y);  info.attackRatio = mean(y);
end
