function s = method_label(m)
switch upper(m)
    case 'FCWSO',    s = 'FCFWSO_GRA-Net (proposed)';
    case 'WSO',      s = 'WSO_GRA-Net';
    case 'COA',      s = 'COA_GRA-Net';
    case 'NONE',     s = 'GRA-Net';
    case 'SHORTEST', s = 'Min-hop routing';
    otherwise,       s = m;
end
end
