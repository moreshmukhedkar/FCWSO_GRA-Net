function [S, v] = classification_metrics(ytrue, ypred)
% Accuracy, precision, recall (TPR), miss rate = FN/(FN+TP) Eq.(24), false alarm = FP/(FP+TN) Eq.(25), F1.
yt = logical(ytrue(:));  yp = logical(ypred(:));
TP = sum(yt & yp);  TN = sum(~yt & ~yp);  FP = sum(~yt & yp);  FN = sum(yt & ~yp);
S.accuracy = (TP+TN)/max(TP+TN+FP+FN,1);   S.precision = TP/max(TP+FP,1);
S.recall = TP/max(TP+FN,1);                S.missRate = FN/max(FN+TP,1);
S.falseAlarm = FP/max(FP+TN,1);            S.f1 = 2*S.precision*S.recall/max(S.precision+S.recall,eps);
v = [S.accuracy S.precision S.recall S.missRate S.falseAlarm S.f1];
end
