function save_csv(file, headers, M)
fid = fopen(file,'w');  fprintf(fid,'%s\n', strjoin(headers,','));
for i = 1:size(M,1), fprintf(fid,'%s\n', strjoin(arrayfun(@(v) sprintf('%.6g',v), M(i,:), 'UniformOutput',false), ',')); end
fclose(fid);
end
