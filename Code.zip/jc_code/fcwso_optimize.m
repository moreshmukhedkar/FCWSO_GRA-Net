function [gbest, gfit, curve] = fcwso_optimize(fun, dim, lb, ub, opt, mode, X0)
% FCWSO_OPTIMIZE  Fractional Crayfish White Shark Optimisation (Sec.4.3).
%   mode 'FCWSO' : hybrid COA + WSO step with fractional-order memory (Eq.13-18)
%   mode 'COA'   : Crayfish Optimization Algorithm only
%   mode 'WSO'   : White Shark Optimizer only
%   fun : handle  f = fun(x)  (x is 1 x dim row, minimised);  X0 : optional initial rows.
if nargin < 7, X0 = []; end
if nargin < 6, mode = 'FCWSO'; end
n = opt.pop;  T = opt.iter;
lb = lb(:)' .* ones(1,dim);  ub = ub(:)' .* ones(1,dim);
X = lb + (ub-lb) .* rand(n,dim);
if ~isempty(X0), mm = min(n,size(X0,1));  X(1:mm,:) = min(max(X0(1:mm,:),lb),ub); end
fit = zeros(n,1);  for i = 1:n, fit(i) = fun(X(i,:)); end
[gfit,ig] = min(fit);  gbest = X(ig,:);
Vel = zeros(n,dim);  H1 = X;  H2 = X;  H3 = X;
a = opt.convRate;                                           % fractional order
c = [a, a*(1-a)/2, a*(1-a)*(2-a)/6, a*(1-a)*(2-a)*(3-a)/24];  c = c / sum(c);   % memory weights
curve = zeros(T,1);
for t = 1:T
    Xc = coa_step(X, fit, gbest, gfit, t, T);
    [Xw, Vel] = wso_step(X, Vel, X, gbest, t, T, lb, ub, opt);
    switch upper(mode)
        case 'COA', Xn = Xc;
        case 'WSO', Xn = Xw;
        otherwise
            dC = Xc - X;  dW = Xw - X;
            mix = opt.envFactor*dC + (1-opt.envFactor)*dW;
            useMix = rand(n,1) < opt.huntProb;
            dH = dC;  dH(useMix,:) = mix(useMix,:);
            Xn = dH + c(1)*X + c(2)*H1 + c(3)*H2 + c(4)*H3;      % fractional update
    end
    H3 = H2;  H2 = H1;  H1 = X;
    Xn = min(max(Xn,lb),ub);
    fn = zeros(n,1);  for i = 1:n, fn(i) = fun(Xn(i,:)); end
    imp = fn < fit;  X(imp,:) = Xn(imp,:);  fit(imp) = fn(imp);
    [bf,ib] = min(fit);  if bf < gfit, gfit = bf;  gbest = X(ib,:); end
    if rand < opt.reproProb                                    % reproduction: child of gbest and a random shark
        [~,iw] = max(fit);  r = randi(n);  mask = rand(1,dim) < 0.5;
        child = gbest.*mask + X(r,:).*(~mask);
        child = min(max(child + 0.01*(ub-lb).*randn(1,dim).*(rand(1,dim)<0.1), lb), ub);
        fc = fun(child);
        if fc < fit(iw), X(iw,:) = child;  fit(iw) = fc;  if fc < gfit, gfit = fc;  gbest = child; end, end
    end
    curve(t) = gfit;
    if gfit <= opt.stopFit, curve = curve(1:t);  break; end
end
end

function Xn = coa_step(X, fit, gbest, gfit, t, T)
% Crayfish step: summer resort / competition (temp>30) or foraging (temp<=30), expressed as moves.
[n,dim] = size(X);  Xn = X;
[~,il] = min(fit);  Xshade = (gbest + X(il,:))/2;                 % cave
temp = rand*15 + 20;  C2 = 2 - t/T;  C3 = 3;
for i = 1:n
    if temp > 30
        if rand < 0.5
            Xn(i,:) = X(i,:) + C2*rand(1,dim).*(Xshade - X(i,:));           % enter cave
        else
            z = randi(n);  Xn(i,:) = X(i,:) - X(z,:) + Xshade;               % competition
        end
    else
        P = 0.2*(1/(sqrt(2*pi)*3))*exp(-(temp-25)^2/(2*3^2));
        Q = C3*rand*fit(i)/(gfit+eps);
        if Q > (C3+1)/2
            Xfood = exp(-1/Q)*gbest;                                          % shred big food
            Xn(i,:) = X(i,:) + cos(2*pi*rand)*Xfood*P - sin(2*pi*rand)*Xfood*P;
        else
            Xn(i,:) = X(i,:) + 0.5*rand(1,dim).*(gbest - X(i,:));            % eat small food
        end
    end
end
end

function [Xn, Vel] = wso_step(X, Vel, pbest, gbest, t, T, lb, ub, opt)
% White shark step: velocity towards best sharks, wavy movement, schooling.
[n,dim] = size(X);
pmin = 0.5;  pmax = 1.5;  tau = 4.11;  mu = 2/abs(2 - tau - sqrt(tau^2 - 4*tau));
a0 = 6.25;  a1 = 100;  a2 = 0.0005;  fmin = 0.07;  fmax = 0.75;
p1 = pmax + (pmax-pmin)*exp(-(4*t/T)^2);   p2 = pmin + (pmax-pmin)*exp(-(4*t/T)^2);
nu = randi(n,n,1);
Vel = mu*(Vel + p1*rand(n,dim).*(gbest - X) + p2*rand(n,dim).*(pbest(nu,:) - X));
f = fmin + (fmax-fmin)/(fmax+fmin);
mv = 1/(a0 + exp((T/2 - t)/a1));   ss = abs(1 - exp(-a2*t/T));
Xn = X + opt.sharkSpeed*Vel/f;
for i = 1:n
    if rand < mv                                                   % wavy movement: redraw a few coordinates
        mask = rand(1,dim) < 0.1*opt.huntRadius;
        Xn(i,mask) = lb(mask) + (ub(mask)-lb(mask)).*rand(1,nnz(mask));
    end
    if rand <= ss                                                  % schooling around best shark
        Dd = abs(rand(1,dim).*(gbest - X(i,:)));
        Xn(i,:) = gbest + rand(1,dim).*Dd.*sign(rand(1,dim)-0.5);
    end
end
end
