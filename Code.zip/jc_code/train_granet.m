function model = train_granet(X, y, cfg, method)
% TRAIN_GRANET  Trains GRA-Net. The feature-extractor parameters (conv kernels, layer-norm, point-wise
%   weights, GRA gamma/beta) are tuned by the optimiser (method 'FCWSO' | 'COA' | 'WSO'); the linear
%   output layer is solved in closed form (ridge) inside every fitness evaluation.
%   method 'none' = plain GRA-Net (no metaheuristic tuning).
y = double(y(:));
[Xs, lo, hi] = minmax_scale(X);
nc = cfg.net;  theta0 = granet_init(cfg);  curve = [];
if ~strcmpi(method,'none')
    idx = stratified_sample(y, min(numel(y), nc.optRows));
    idx = idx(randperm(numel(idx)));  nf = round(0.75*numel(idx));
    Xa = Xs(idx(1:nf),:);  ya = y(idx(1:nf));  Xv = Xs(idx(nf+1:end),:);  yv = y(idx(nf+1:end));
    fun = @(th) fitness_head(th, Xa, ya, Xv, yv, cfg);
    X0 = theta0 + [zeros(1,numel(theta0)); 0.05*randn(nc.pop-1, numel(theta0))];
    opt = cfg.opt;  opt.pop = nc.pop;  opt.iter = nc.iter;
    [theta, ~, curve] = fcwso_optimize(fun, numel(theta0), -3, 3, opt, method, X0);
else
    theta = theta0;
end
head = fit_head(granet_features(theta, Xs, cfg), y, nc.ridge);
model = struct('theta',theta,'head',head,'lo',lo,'hi',hi,'curve',curve);
end

function f = fitness_head(th, Xa, ya, Xv, yv, cfg)
h = fit_head(granet_features(th, Xa, cfg), ya, cfg.net.ridge);
s = head_score(h, granet_features(th, Xv, cfg));
f = 0.5*mean((s - yv).^2) + 0.5*(1 - mean((s >= 0.5) == yv));
end
