%% MAIN_FCFWSO_GRANET  Trust-based intrusion detection in MANET with FCFWSO_GRA-Net
%  Pipeline: MANET simulation (energy/mobility/trust models) -> FCWSO routing -> GRA-Net trust updation
%            -> base-station log pre-processing -> GRA-Net intrusion detection tuned by FCWSO
%            -> analyses: routing, scalability (100..500 nodes), detection vs k.
%  Run:  main_FCFWSO_GRANet            (set FAST = true below for a quick smoke test)
clear; clc; close all;
FAST = false;
cfg = config_FCFWSO(FAST);
if ~exist(cfg.resultsDir,'dir'), mkdir(cfg.resultsDir); end
rng(cfg.seed);

%% 1) Trust network (GRA-Net) for trust updation
fprintf('[1] Training GRA-Net trust-updation model...\n');
tnet = train_trust_net(cfg);

%% 2) MANET simulation + FCWSO routing (Fig.5-style plots, 50 and 100 nodes)
fprintf('[2] MANET simulation with FCWSO routing...\n');
for N = [50 100]
    o = simulate_manet(cfg, N, 'FCWSO', cfg.seed, tnet);
    plot_manet(o.snap, cfg, N);
    fprintf('    N=%3d  PDR=%.3f  thr=%.2f kbps  delay=%.3f ms  energy=%.2f J  dist=%.1f m  life=%.1f s  trustAcc=%.2f\n', ...
        N, o.pdr(end), o.throughput(end), o.delay_ms(end), o.energy(end), o.distance(end), o.lifetime(end), o.trustAcc(end));
end

%% 3) Intrusion detection at the base station (k-fold, both datasets)
fprintf('[3] Intrusion detection (k = %d fold)...\n', cfg.kDefault);
sets = {'NSL-KDD','CIC-IDS2018'};  T = zeros(numel(sets), 6);
for d = 1:numel(sets)
    [X,y,info] = load_dataset(sets{d}, cfg);
    fprintf('    %s: %d rows, %d features, attack ratio %.2f\n', sets{d}, info.n, info.numFeatures, info.attackRatio);
    T(d,:) = evaluate_kfold(X, y, cfg, 'FCWSO', cfg.kDefault);
end
H = {'Accuracy','Precision','Recall','MissRate','FalseAlarm','F1'};
fprintf('\n    %-12s', 'Dataset');  fprintf('%-11s', H{:});  fprintf('\n');
for d = 1:numel(sets), fprintf('    %-12s', sets{d});  fprintf('%-11.4f', T(d,:));  fprintf('\n'); end
save_csv(fullfile(cfg.resultsDir,'detection_summary.csv'), H, T);

%% 4) Analyses
fprintf('[4a] Routing analysis...\n');      analysis_routing(cfg, tnet);
fprintf('[4b] Scalability analysis...\n');  analysis_scalability(cfg, tnet);
fprintf('[4c] k-value analysis...\n');      analysis_kvalue(cfg);
fprintf('Done. Figures and CSV files are in "%s".\n', cfg.resultsDir);
