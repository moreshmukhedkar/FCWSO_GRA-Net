function F = granet_features(theta, X, cfg)
% GRANET_FEATURES  Forward pass of GRA-Net (Fig.3) on tabular rows X (n x d) -> pooled features (n x L*P).
%   stem -> [depth-wise large-kernel conv -> LayerNorm -> point-wise expand -> GRA -> point-wise project + residual] x blocks
%   -> adaptive average pooling along the feature axis.
P = granet_unpack(theta, cfg);  nc = cfg.net;
n = size(X,1);  d = size(X,2);  Pn = min(nc.pool, d);
F = zeros(n, nc.L*Pn);  bs = 4000;
for s = 1:bs:n
    idx = s:min(n,s+bs-1);
    F(idx,:) = forward_batch(P, X(idx,:), nc, Pn);
end
end

function F = forward_batch(P, X, nc, Pn)
[n,d] = size(X);  L = nc.L;  M = nc.expand*L;  pad = floor(nc.ks/2);
H = reshape(X,n,d,1) .* reshape(P.stem_w,1,1,L) + reshape(P.stem_b,1,1,L);      % n x d x L
for b = 1:nc.blocks
    B = P.blk(b);
    Hp = zeros(n,d+2*pad,L);  Hp(:,pad+1:pad+d,:) = H;
    Y = zeros(n,d,L);
    for k = 1:nc.ks
        Y = Y + Hp(:,k:k+d-1,:) .* reshape(B.dw_w(:,k),1,1,L);                   % depth-wise conv
    end
    mu = mean(Y,3);  sd = sqrt(mean((Y-mu).^2,3) + 1e-6);
    Y = (Y-mu)./sd .* reshape(B.ln_g,1,1,L) + reshape(B.ln_b,1,1,L);             % layer norm
    Y = reshape(reshape(Y,n*d,L)*B.pw1_w + B.pw1_b, n, d, M);                    % expand
    Y = gra(Y, B.gamma, B.beta, nc.groups, M);                                   % GRA replaces activation
    Y = reshape(reshape(Y,n*d,M)*B.pw2_w + B.pw2_b, n, d, L);                    % project
    H = H + Y;
end
e = round(linspace(0,d,Pn+1));  F = zeros(n,L*Pn);
for p = 1:Pn
    F(:,(p-1)*L+(1:L)) = reshape(mean(H(:,e(p)+1:e(p+1),:),2), n, L);
end
end

function Y = gra(X, gamma, beta, G, M)
% Group Response Attention: group L2 response (Eq.19) -> normalised attention (Eq.20) -> Eq.(21).
[n,d,~] = size(X);  cg = M/G;
Xg = reshape(X,n,d,cg,G);
r  = reshape(sqrt(sum(sum(Xg.^2,2),3) + 1e-6), n, G);          % group response
a  = r ./ (mean(r,2) + 1e-6);                                  % attention weights
A  = reshape(repmat(reshape(a,n,1,1,G),[1 1 cg 1]), n, 1, M);
Y  = reshape(gamma,1,1,M) .* (X .* A) + reshape(beta,1,1,M) + X;
end
