function theta = granet_init(cfg)
% GRANET_INIT  Initial parameter vector of GRA-Net (gamma, beta = 0 as in Eq.21).
nc = cfg.net;  L = nc.L;  M = nc.expand*L;  ks = nc.ks;
theta = [randn(1,L)*sqrt(2), zeros(1,L)];                          % stem (1 -> L)
for b = 1:nc.blocks
    theta = [theta, randn(1,L*ks)*sqrt(2/ks)];                     % depth-wise large-kernel conv
    theta = [theta, ones(1,L), zeros(1,L)];                        % layer-norm gain / bias
    theta = [theta, randn(1,L*M)*sqrt(2/L), zeros(1,M)];           % point-wise expansion
    theta = [theta, zeros(1,M), zeros(1,M)];                       % GRA gamma, beta (zero init)
    theta = [theta, 0.5*randn(1,M*L)*sqrt(2/M), zeros(1,L)];       % point-wise projection
end
end
