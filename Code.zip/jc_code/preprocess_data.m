function [X, info] = preprocess_data(raw)
% PREPROCESS_DATA  Sec.4.5.2: handling missing values (impute / drop), categorical encoding
%   (one-hot for <=8 levels, label encoding otherwise), heavy-tail log scaling. Min-max normalisation
%   is applied later with training-fold statistics (minmax_scale).
blocks = {};  dropped = 0;
for j = 1:numel(raw.cols)
    c = raw.cols{j};
    if iscell(c)
        num = str2double(c(:));
        if any(~isnan(num)) && mean(isnan(num)) < 0.05, c = num; end
    end
    if iscell(c)                                         % categorical
        c = c(:);  c(cellfun(@isempty,c)) = {'unknown'};
        [u,~,code] = unique(c);
        if numel(u) <= 8, B = double(code == 1:numel(u)); else, B = double(code); end
    else                                                 % numeric
        c = double(c(:));  c(isinf(c)) = NaN;
        if mean(isnan(c)) > 0.5, dropped = dropped + 1; continue; end
        ok = ~isnan(c);  c(~ok) = median(c(ok));         % median imputation
        if min(c) >= 0 && max(c) > 1e3*(median(c) + 1), c = log1p(c); end
        B = c;
    end
    B = B(:, max(B,[],1) > min(B,[],1));                 % drop constant columns
    if ~isempty(B), blocks{end+1} = B; end %#ok<AGROW>
end
X = [blocks{:}];
info.numFeatures = size(X,2);  info.droppedColumns = dropped;
end
