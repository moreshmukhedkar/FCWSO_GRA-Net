function [pred, s] = granet_predict(model, X, cfg)
Xs = minmax_scale(X, model.lo, model.hi);
s = head_score(model.head, granet_features(model.theta, Xs, cfg));
pred = s >= 0.5;
end
