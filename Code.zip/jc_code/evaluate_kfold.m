function [mv, folds] = evaluate_kfold(X, y, cfg, method, k)
% EVALUATE_KFOLD  Stratified k-fold evaluation of GRA-Net trained with 'FCWSO'|'WSO'|'COA'|'none'.
%   mv = mean [accuracy precision recall missRate falseAlarm f1] over folds.
fold = stratified_folds(y, k);  folds = zeros(k,6);
for f = 1:k
    te = fold == f;
    model = train_granet(X(~te,:), y(~te), cfg, method);
    pred = granet_predict(model, X(te,:), cfg);
    [~, folds(f,:)] = classification_metrics(y(te), pred);
end
mv = mean(folds,1);
end
