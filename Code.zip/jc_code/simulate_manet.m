function out = simulate_manet(cfg, N, method, seed, tnet)
% SIMULATE_MANET  Mobility -> trust update (GRA-Net) -> routing -> packet transmission, repeated every
%   cfg.routeInterval seconds. method: 'FCWSO' | 'COA' | 'WSO' | 'SHORTEST'.
%   The scenario (topology, flows) uses its own random stream, so all methods see the same network.
rng(seed);
net = create_manet(cfg, N);
nI = floor(cfg.simTime / cfg.routeInterval);
sent = 0; deliv = 0; dlySum = 0; distAcc = []; hopAcc = []; dly8Acc = [];
z = zeros(1,nI);
out = struct('t',z,'pdr',z,'throughput',z,'delay_ms',z,'energy',z,'lifetime',z,'distance',z, ...
             'hops',z,'delayEq8',z,'trustAcc',z,'snap',[]);
for it = 1:nI
    if it > 1, net = update_mobility(net, cfg, cfg.routeInterval); end
    m = node_metrics(net, cfg);
    feat = trust_model(net, cfg, m);
    net.trust = trust_update_granet(tnet, feat, net.trust, cfg);      % GRA-Net trust updation
    m.T = net.trust;
    out.trustAcc(it) = mean((net.trust < cfg.trustThr) == net.isMal);
    for f = 1:cfg.numFlows
        [src,dst] = pick_flow(m.A, net.energy > 0);
        if isempty(src), continue; end
        oseed = randi(1e6);  tseed = randi(1e6);  envS = rng;
        rng(oseed);  path = find_route(method, m, net, cfg, src, dst);
        rng(tseed);  [net, res] = transmit(net, cfg, m, path);
        rng(envS);
        sent = sent + res.sent;  deliv = deliv + res.deliv;  dlySum = dlySum + res.dlySum;
        distAcc(end+1) = sum(m.D(sub2ind([N N], path(1:end-1), path(2:end)))); %#ok<AGROW>
        hopAcc(end+1)  = numel(path) - 1;  dly8Acc(end+1) = numel(path)/N; %#ok<AGROW>
        if it == 1 && f == 1
            out.snap = struct('pos',net.pos,'src',src,'dst',dst,'path',path,'isMal',net.isMal,'time',net.time);
        end
    end
    net.time = it * cfg.routeInterval;
    rate = net.spent / net.time;  used = rate > 1e-9;
    out.t(it) = net.time;
    out.pdr(it) = deliv / max(sent,1);
    out.throughput(it) = min(cfg.bandwidthKbps, deliv*cfg.pktBits/net.time/1e3);   % kbps
    out.delay_ms(it) = dlySum / max(deliv,1);
    out.energy(it) = mean(net.energy);                                 % mean residual energy (J)
    out.lifetime(it) = net.time + min([net.energy(used)./rate(used); 1e4]);        % projected first-node-death (s)
    out.distance(it) = mean(distAcc);   out.hops(it) = mean(hopAcc);   out.delayEq8(it) = mean(dly8Acc);
end
end

function [src,dst] = pick_flow(A, alive)
cand = find(alive);
for k = 1:20
    s = cand(randi(numel(cand)));  h = bfs_hops(A, s);
    ok = find(isfinite(h) & h >= 2);
    if ~isempty(ok), src = s; dst = ok(randi(numel(ok))); return; end
end
src = []; dst = [];
end

function path = find_route(method, m, net, cfg, src, dst)
if strcmpi(method,'SHORTEST')
    path = route_shortest(m.A, src, dst);
else
    fun = @(key) routing_fitness(decode_route(key, m.A, src, dst), net, cfg, m);
    best = fcwso_optimize(fun, net.N, 0, 1, cfg.opt, method);
    path = decode_route(best, m.A, src, dst);
end
if isempty(path), path = route_shortest(m.A, src, dst); end
end

function [net, res] = transmit(net, cfg, m, path)
nP = round(cfg.pktRate * cfg.routeInterval);   h = numel(path) - 1;
pd = cfg.dropHon*ones(net.N,1);  pd(net.isMal) = cfg.dropMal;
res = struct('sent',nP,'deliv',0,'dlySum',0);
for p = 1:nP
    ok = true;  dly = 0;
    for k = 1:h
        a = path(k);  b = path(k+1);
        if net.energy(a) <= 0, ok = false; break; end
        net.energy(a) = max(0, net.energy(a) - cfg.Etx);  net.spent(a) = net.spent(a) + cfg.Etx;
        net.energy(b) = max(0, net.energy(b) - cfg.Erx);  net.spent(b) = net.spent(b) + cfg.Erx;
        dly = dly - log(rand) + 0.05*m.deg(a);                          % queue + contention (ms)
        if k < h                                                        % b is a relay
            net.fwdTot(b) = net.fwdTot(b) + 1;
            if rand < pd(b) || net.energy(b) <= 0, ok = false; break; end
            net.fwdOK(b) = net.fwdOK(b) + 1;
        end
    end
    if ok && dly <= cfg.maxDelayMs
        res.deliv = res.deliv + 1;  res.dlySum = res.dlySum + dly;
    end
end
end
