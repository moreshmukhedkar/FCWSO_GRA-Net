function idx = stratified_sample(y, n)
% Random subset of n rows that keeps the class ratio.
y = y(:);  idx = [];
for c = unique(y)'
    ic = find(y == c);  k = max(1, round(n*numel(ic)/numel(y)));
    ic = ic(randperm(numel(ic)));  idx = [idx; ic(1:min(k,numel(ic)))]; %#ok<AGROW>
end
end
