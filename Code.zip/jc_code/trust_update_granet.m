function Tnew = trust_update_granet(tnet, feat, Told, cfg)
% TRUST_UPDATE_GRANET  Trust updation with GRA-Net (Sec.4.4): new trust = 0.5*old + 0.5*GRA-Net score.
[~, s] = granet_predict(tnet, feat, cfg);
Tnew = 0.5*Told + 0.5*min(max(s,0),1);
end
