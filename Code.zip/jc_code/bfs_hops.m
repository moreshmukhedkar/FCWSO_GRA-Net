function h = bfs_hops(A, s)
% BFS_HOPS  Hop distance from node s to all nodes (Inf if unreachable).
N = size(A,1);  h = inf(N,1);  h(s) = 0;  q = zeros(N,1);  qh = 1;  qt = 1;  q(1) = s;
while qh <= qt
    u = q(qh);  qh = qh + 1;
    nb = find(A(u,:) & isinf(h'));
    h(nb) = h(u) + 1;  q(qt+1:qt+numel(nb)) = nb;  qt = qt + numel(nb);
end
end
