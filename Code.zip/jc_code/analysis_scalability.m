function R = analysis_scalability(cfg, tnet)
% ANALYSIS_SCALABILITY  Number of nodes varied (cfg.nodeList, default 100..500).
M = cfg.routeMethods;  NL = cfg.nodeList;
flds  = {'pdr','throughput','lifetime','delay_ms','energy','distance'};
names = {'PDR','Throughput (kbps)','Network lifetime (s)','End-to-end delay (ms)','Residual energy (J)','Route distance (m)'};
R = zeros(numel(NL), numel(M), numel(flds));
for a = 1:numel(NL)
    for i = 1:numel(M)
        fprintf('  scalability: %d nodes, %s\n', NL(a), method_label(M{i}));
        o = simulate_manet(cfg, NL(a), M{i}, cfg.seed, tnet);
        for k = 1:numel(flds), R(a,i,k) = o.(flds{k})(end); end
    end
end
figure('Visible', cfg.plotVisible, 'Position',[50 50 1250 650]);
for k = 1:numel(flds)
    subplot(2,3,k);  plot(NL, squeeze(R(:,:,k)), '-o', 'LineWidth',1.4);
    xlabel('Number of nodes');  ylabel(names{k});  grid on;  box on;
    if k == 1, legend(cellfun(@method_label, M, 'UniformOutput',false), 'Location','best'); end
end
sgtitle('Scalability analysis');
saveas(gcf, fullfile(cfg.resultsDir, 'fig_scalability.png'));
H = {'nodes'};  Mx = NL(:);
for i = 1:numel(M), for k = 1:numel(flds), H{end+1} = [M{i} '_' flds{k}];  Mx = [Mx R(:,i,k)]; end, end %#ok<AGROW>
save_csv(fullfile(cfg.resultsDir,'scalability.csv'), H, Mx);
end
