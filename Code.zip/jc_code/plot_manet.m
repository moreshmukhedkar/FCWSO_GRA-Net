function plot_manet(snap, cfg, N)
% Fig.5-style snapshot: nodes blue, source pink, destination red, malicious nodes black x, selected route green.
figure('Visible', cfg.plotVisible);  hold on;
scatter(snap.pos(:,1), snap.pos(:,2), 40, 'b', 'filled');
scatter(snap.pos(snap.isMal,1), snap.pos(snap.isMal,2), 60, 'k', 'x');
scatter(snap.pos(snap.src,1), snap.pos(snap.src,2), 110, [1 0.4 0.7], 'filled');
scatter(snap.pos(snap.dst,1), snap.pos(snap.dst,2), 110, 'r', 'filled');
plot(snap.pos(snap.path,1), snap.pos(snap.path,2), 'g-', 'LineWidth', 2);
legend({'Nodes','Malicious','Source','Destination','Route'}, 'Location','bestoutside');
xlabel('Width (m)'); ylabel('Height (m)');
title(sprintf('MANET simulation: %d nodes, data sent at t = %d s', N, snap.time));  box on;
saveas(gcf, fullfile(cfg.resultsDir, sprintf('fig_manet_%dnodes.png', N)));
end
