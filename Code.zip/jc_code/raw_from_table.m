function raw = raw_from_table(T)
% Table -> struct of columns (numeric vectors or cellstr).
raw.cols = cell(1,width(T));
for j = 1:width(T)
    c = T.(j);
    if isstring(c) || iscategorical(c), c = cellstr(c); end
    raw.cols{j} = c;
end
end
