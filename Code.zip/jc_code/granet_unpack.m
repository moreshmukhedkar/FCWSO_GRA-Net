function P = granet_unpack(theta, cfg)
% GRANET_UNPACK  Parameter vector -> struct (same order as granet_init).
nc = cfg.net;  L = nc.L;  M = nc.expand*L;  ks = nc.ks;  pos = 0;
[P.stem_w,pos] = tk(theta,pos,[1 L]);  [P.stem_b,pos] = tk(theta,pos,[1 L]);
for b = 1:nc.blocks
    [B.dw_w,pos]  = tk(theta,pos,[L ks]);
    [B.ln_g,pos]  = tk(theta,pos,[1 L]);   [B.ln_b,pos]  = tk(theta,pos,[1 L]);
    [B.pw1_w,pos] = tk(theta,pos,[L M]);   [B.pw1_b,pos] = tk(theta,pos,[1 M]);
    [B.gamma,pos] = tk(theta,pos,[1 M]);   [B.beta,pos]  = tk(theta,pos,[1 M]);
    [B.pw2_w,pos] = tk(theta,pos,[M L]);   [B.pw2_b,pos] = tk(theta,pos,[1 L]);
    P.blk(b) = B;
end
end
function [v,pos] = tk(theta,pos,sz)
n = prod(sz);  v = reshape(theta(pos+1:pos+n), sz);  pos = pos + n;
end
