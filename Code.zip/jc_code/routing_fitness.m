function f = routing_fitness(path, net, cfg, m)
% ROUTING_FITNESS  Eq.(7): weighted sum of normalised energy, distance, delay, trust, power,
%   connectivity, link lifetime and mobility terms (all minimised, in [0,1]).
if isempty(path), f = 10; return; end
N = net.N;  L = numel(path);
links = sub2ind([N N], path(1:end-1), path(2:end));
E  = mean(m.Enorm(path));                                   % Eq.(1)
Dn = min(1, sum(m.D(links)) / (2*sqrt(sum(cfg.area.^2))));  % Eq.(9)
Dl = L / N;                                                 % Eq.(8): participating nodes / total nodes
Tp = m.T(path);  Tn = 0.5*mean(Tp) + 0.5*min(Tp);           % Eq.(5)-(6) via updated trust
Pn = mean(m.Pl(links));                                     % Eq.(10)
Cn = mean(m.conn(path));                                    % Eq.(11)
Ln = mean(m.life(path));                                    % Eq.(12)
Mn = mean(m.mob(path));                                     % Eq.(4)
f = cfg.fitW * [1-E; Dn; Dl; 1-Tn; 1-Pn; 1-Cn; 1-Ln; Mn];
if L > 2 && min(m.T(path(2:end-1))) < cfg.trustThr, f = f + 1; end   % untrusted relay penalty
end
